package com.market.supermarket.ui.screens

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.market.supermarket.data.Product
import com.market.supermarket.util.money

@Composable
fun SaleScreen(
    products: List<Product>,
    onSell: (product: Product, quantitySold: Int) -> Unit
) {

    var selectedProduct by remember { mutableStateOf<Product?>(null) }
    var quantity by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        item {
            Text(
                "🧾 تسجيل بيع",
                style = MaterialTheme.typography.headlineSmall
            )
            Spacer(modifier = Modifier.height(15.dp))
        }

        items(products) { product ->
            Button(
                onClick = { selectedProduct = product },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
            ) {
                Text("${product.name} - ${money(product.sellPrice)}")
            }
        }

        item {
            selectedProduct?.let { product ->

                Spacer(modifier = Modifier.height(15.dp))

                Text("المنتج: ${product.name}")
                Text("المخزون: ${product.quantity}")

                OutlinedTextField(
                    value = quantity,
                    onValueChange = { quantity = it },
                    label = { Text("الكمية المباعة") },
                    modifier = Modifier.fillMaxWidth()
                )

                Button(
                    onClick = {
                        val qty = quantity.toIntOrNull() ?: 0

                        if (qty > 0 && qty <= product.quantity) {
                            onSell(product, qty)
                            quantity = ""
                            selectedProduct = null
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("إتمام البيع")
                }
            }
        }
    }
}
