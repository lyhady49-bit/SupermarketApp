package com.market.supermarket.navigation

sealed class Screen(
    val route: String,
    val label: String,
    val icon: String
) {
    object Home : Screen("home", "الرئيسية", "🏠")
    object Products : Screen("products", "المنتجات", "📦")
    object Sale : Screen("sale", "بيع", "🧾")
    object Reports : Screen("reports", "التقارير", "📊")
    object Scanner : Screen("scanner", "مسح الباركود", "📷")

    companion object {
        val bottomBarScreens = listOf(Home, Products, Sale, Reports)
    }
}
