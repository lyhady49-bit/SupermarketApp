package com.market.supermarket.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.market.supermarket.data.Expense
import com.market.supermarket.data.MarketRepository
import com.market.supermarket.data.Product
import com.market.supermarket.data.Sale
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MarketViewModel(
    private val repository: MarketRepository
) : ViewModel() {

    val products: StateFlow<List<Product>> =
        repository.products.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

    val sales: StateFlow<List<Sale>> =
        repository.sales.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

    val expenses: StateFlow<List<Expense>> =
        repository.expenses.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

    fun addProduct(
        name: String,
        barcode: String,
        buyPrice: Double,
        sellPrice: Double,
        quantity: Int,
        minQuantity: Int,
        imageUri: String?
    ) {
        viewModelScope.launch {
            repository.addProduct(
                Product(
                    name = name,
                    barcode = barcode,
                    buyPrice = buyPrice,
                    sellPrice = sellPrice,
                    quantity = quantity,
                    minQuantity = minQuantity,
                    imageUri = imageUri
                )
            )
        }
    }

    fun sellProduct(product: Product, quantitySold: Int) {
        viewModelScope.launch {
            repository.sellProduct(product, quantitySold)
        }
    }

    fun addExpense(name: String, amount: Double) {
        viewModelScope.launch {
            repository.addExpense(
                Expense(
                    name = name,
                    amount = amount,
                    date = System.currentTimeMillis()
                )
            )
        }
    }

    class Factory(
        private val repository: MarketRepository
    ) : ViewModelProvider.Factory {

        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MarketViewModel(repository) as T
        }
    }
}
