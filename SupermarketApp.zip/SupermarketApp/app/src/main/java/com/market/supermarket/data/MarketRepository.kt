package com.market.supermarket.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow

class MarketRepository(
    private val db: AppDatabase,
    private val productDao: ProductDao,
    private val saleDao: SaleDao,
    private val expenseDao: ExpenseDao
) {

    val products: Flow<List<Product>> = productDao.getAll()
    val sales: Flow<List<Sale>> = saleDao.getAll()
    val expenses: Flow<List<Expense>> = expenseDao.getAll()

    suspend fun addProduct(product: Product) {
        productDao.insert(product)
    }

    suspend fun addExpense(expense: Expense) {
        expenseDao.insert(expense)
    }

    /**
     * Reduces stock and records the sale in a single DB transaction,
     * mirroring the original in-memory logic (total, cost, profit).
     */
    suspend fun sellProduct(product: Product, quantitySold: Int) {
        db.withTransaction {
            val total = product.sellPrice * quantitySold
            val cost = product.buyPrice * quantitySold
            val profit = total - cost

            val updated = product.copy(
                quantity = product.quantity - quantitySold
            )
            productDao.update(updated)

            saleDao.insert(
                Sale(
                    productId = product.id,
                    productName = product.name,
                    quantity = quantitySold,
                    total = total,
                    profit = profit,
                    date = System.currentTimeMillis()
                )
            )
        }
    }
}
