package com.market.supermarket.util

import java.util.Locale

fun money(value: Double): String {
    return "%,.0f د.ع".format(Locale.US, value)
}
