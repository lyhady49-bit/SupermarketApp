package com.market.supermarket

import android.app.Application
import com.market.supermarket.data.AppDatabase
import com.market.supermarket.data.MarketRepository

class MarketApplication : Application() {

    private val database by lazy { AppDatabase.getInstance(this) }

    val repository by lazy {
        MarketRepository(
            db = database,
            productDao = database.productDao(),
            saleDao = database.saleDao(),
            expenseDao = database.expenseDao()
        )
    }
}
