package com.market.supermarket.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.market.supermarket.ui.barcode.BarcodeScannerScreen
import com.market.supermarket.ui.screens.HomeScreen
import com.market.supermarket.ui.screens.ProductsScreen
import com.market.supermarket.ui.screens.ReportsScreen
import com.market.supermarket.ui.screens.SaleScreen
import com.market.supermarket.viewmodel.MarketViewModel

@Composable
fun MarketNavHost(viewModel: MarketViewModel) {

    val navController = rememberNavController()

    val products by viewModel.products.collectAsState()
    val sales by viewModel.sales.collectAsState()
    val expenses by viewModel.expenses.collectAsState()

    Scaffold(
        bottomBar = {
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = navBackStackEntry?.destination

            NavigationBar {
                Screen.bottomBarScreens.forEach { screen ->

                    val selected = currentDestination?.hierarchy?.any {
                        it.route == screen.route
                    } == true

                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Text(screen.icon) },
                        label = { Text(screen.label) }
                    )
                }
            }
        }
    ) { padding ->

        Box(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {

            NavHost(
                navController = navController,
                startDestination = Screen.Home.route
            ) {

                composable(Screen.Home.route) {
                    HomeScreen(
                        products = products,
                        sales = sales,
                        expenses = expenses
                    )
                }

                composable(Screen.Products.route) { backStackEntry ->

                    val scannedBarcode = backStackEntry
                        .savedStateHandle
                        .getStateFlow<String?>("scanned_barcode", null)
                        .collectAsState()

                    ProductsScreen(
                        products = products,
                        scannedBarcode = scannedBarcode.value,
                        onBarcodeConsumed = {
                            backStackEntry.savedStateHandle["scanned_barcode"] = null
                        },
                        onScanRequested = {
                            navController.navigate(Screen.Scanner.route)
                        },
                        onAddProduct = { name, barcode, buy, sell, qty, minQty, imageUri ->
                            viewModel.addProduct(name, barcode, buy, sell, qty, minQty, imageUri)
                        }
                    )
                }

                composable(Screen.Sale.route) {
                    SaleScreen(
                        products = products,
                        onSell = { product, qty ->
                            viewModel.sellProduct(product, qty)
                        }
                    )
                }

                composable(Screen.Reports.route) {
                    ReportsScreen(
                        sales = sales,
                        expenses = expenses
                    )
                }

                composable(Screen.Scanner.route) {
                    BarcodeScannerScreen(
                        onBarcodeScanned = { code ->
                            navController.previousBackStackEntry
                                ?.savedStateHandle
                                ?.set("scanned_barcode", code)
                            navController.popBackStack()
                        },
                        onCancel = {
                            navController.popBackStack()
                        }
                    )
                }
            }
        }
    }
}
