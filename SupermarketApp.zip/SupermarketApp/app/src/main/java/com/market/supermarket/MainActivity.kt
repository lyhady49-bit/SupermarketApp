package com.market.supermarket

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.market.supermarket.navigation.MarketNavHost
import com.market.supermarket.viewmodel.MarketViewModel

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val app = application as MarketApplication

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {

                    val viewModel: MarketViewModel = viewModel(
                        factory = MarketViewModel.Factory(app.repository)
                    )

                    MarketNavHost(viewModel = viewModel)
                }
            }
        }
    }
}
