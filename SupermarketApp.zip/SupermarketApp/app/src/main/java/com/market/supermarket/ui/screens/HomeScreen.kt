package com.market.supermarket.ui.screens

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.market.supermarket.data.Expense
import com.market.supermarket.data.Product
import com.market.supermarket.data.Sale
import com.market.supermarket.ui.components.InfoCard
import com.market.supermarket.util.money
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    products: List<Product>,
    sales: List<Sale>,
    expenses: List<Expense>
) {

    val today = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
    val month = SimpleDateFormat("yyyyMM", Locale.getDefault()).format(Date())

    val todaySales = sales
        .filter { SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date(it.date)) == today }
        .sumOf { it.total }

    val todayProfit = sales
        .filter { SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date(it.date)) == today }
        .sumOf { it.profit }

    val monthProfit = sales
        .filter { SimpleDateFormat("yyyyMM", Locale.getDefault()).format(Date(it.date)) == month }
        .sumOf { it.profit }

    val monthExpenses = expenses
        .filter { SimpleDateFormat("yyyyMM", Locale.getDefault()).format(Date(it.date)) == month }
        .sumOf { it.amount }

    val netProfit = monthProfit - monthExpenses

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        item {
            Text(
                text = "🛒 ماركت",
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(modifier = Modifier.height(20.dp))
        }

        item { InfoCard(title = "💰 مبيعات اليوم", value = money(todaySales)) }
        item { InfoCard(title = "📈 ربح اليوم", value = money(todayProfit)) }
        item { InfoCard(title = "💵 ربح الشهر", value = money(monthProfit)) }
        item { InfoCard(title = "💸 مصاريف الشهر", value = money(monthExpenses)) }
        item { InfoCard(title = "💰 صافي الربح الشهري", value = money(netProfit)) }
        item { InfoCard(title = "📦 عدد المنتجات", value = products.size.toString()) }

        item {
            Spacer(modifier = Modifier.height(15.dp))
            Text(
                text = "المخزون المنخفض",
                style = MaterialTheme.typography.titleLarge
            )
        }

        items(products.filter { it.quantity <= it.minQuantity }) { product ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 5.dp)
            ) {
                Column(modifier = Modifier.padding(15.dp)) {
                    Text(product.name)
                    Text("الكمية: ${product.quantity}")
                    Text("⚠️ المخزون منخفض")
                }
            }
        }
    }
}
