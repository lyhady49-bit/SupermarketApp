package com.market.supermarket.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.market.supermarket.data.Expense
import com.market.supermarket.data.Sale
import com.market.supermarket.ui.components.InfoCard
import com.market.supermarket.util.money
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ReportsScreen(
    sales: List<Sale>,
    expenses: List<Expense>
) {

    val month = SimpleDateFormat("yyyyMM", Locale.getDefault()).format(Date())

    val monthSales = sales.filter {
        SimpleDateFormat("yyyyMM", Locale.getDefault()).format(Date(it.date)) == month
    }

    val totalSales = monthSales.sumOf { it.total }
    val totalProfit = monthSales.sumOf { it.profit }

    val totalExpenses = expenses
        .filter { SimpleDateFormat("yyyyMM", Locale.getDefault()).format(Date(it.date)) == month }
        .sumOf { it.amount }

    val net = totalProfit - totalExpenses

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            "📊 التقرير الشهري",
            style = MaterialTheme.typography.headlineSmall
        )

        Spacer(modifier = Modifier.height(20.dp))

        InfoCard("إجمالي المبيعات", money(totalSales))
        InfoCard("إجمالي الربح", money(totalProfit))
        InfoCard("المصاريف", money(totalExpenses))
        InfoCard("صافي الربح", money(net))
    }
}
