package com.market.supermarket.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.market.supermarket.data.Product
import com.market.supermarket.util.money

@Composable
fun ProductsScreen(
    products: List<Product>,
    scannedBarcode: String?,
    onBarcodeConsumed: () -> Unit,
    onScanRequested: () -> Unit,
    onAddProduct: (
        name: String,
        barcode: String,
        buyPrice: Double,
        sellPrice: Double,
        quantity: Int,
        minQuantity: Int,
        imageUri: String?
    ) -> Unit
) {
    val context = LocalContext.current

    var name by remember { mutableStateOf("") }
    var barcode by remember { mutableStateOf("") }
    var buy by remember { mutableStateOf("") }
    var sell by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var minQuantity by remember { mutableStateOf("") }
    var imageUri by remember { mutableStateOf<Uri?>(null) }

    // Fill in the barcode field once the scanner screen returns a result
    LaunchedEffect(scannedBarcode) {
        if (scannedBarcode != null) {
            barcode = scannedBarcode
            onBarcodeConsumed()
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: SecurityException) {
                // Some picked media doesn't support persistable permissions; safe to ignore
            }
            imageUri = uri
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        item {
            Text(
                "📦 إضافة منتج",
                style = MaterialTheme.typography.headlineSmall
            )
            Spacer(modifier = Modifier.height(15.dp))
        }

        item {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("اسم المنتج") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = barcode,
                onValueChange = { barcode = it },
                label = { Text("الباركود") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Button(
                onClick = onScanRequested,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("📷 مسح الباركود")
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))

            if (imageUri != null) {
                AsyncImage(
                    model = imageUri,
                    contentDescription = "صورة المنتج",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(120.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            OutlinedButton(
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(
                            ActivityResultContracts.PickVisualMedia.ImageOnly
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (imageUri == null) "🖼️ إضافة صورة المنتج" else "🖼️ تغيير الصورة")
            }
        }

        item {
            OutlinedTextField(
                value = buy,
                onValueChange = { buy = it },
                label = { Text("سعر الشراء") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = sell,
                onValueChange = { sell = it },
                label = { Text("سعر البيع") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = quantity,
                onValueChange = { quantity = it },
                label = { Text("عدد القطع") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = minQuantity,
                onValueChange = { minQuantity = it },
                label = { Text("الحد الأدنى للمخزون") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Button(
                onClick = {
                    if (name.isNotBlank() && buy.isNotBlank() && sell.isNotBlank() && quantity.isNotBlank()) {

                        onAddProduct(
                            name,
                            barcode,
                            buy.toDoubleOrNull() ?: 0.0,
                            sell.toDoubleOrNull() ?: 0.0,
                            quantity.toIntOrNull() ?: 0,
                            minQuantity.toIntOrNull() ?: 5,
                            imageUri?.toString()
                        )

                        name = ""
                        barcode = ""
                        buy = ""
                        sell = ""
                        quantity = ""
                        minQuantity = ""
                        imageUri = null
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("➕ إضافة المنتج")
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                "المنتجات",
                style = MaterialTheme.typography.titleLarge
            )
        }

        items(products) { product ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(15.dp)) {

                    if (product.imageUri != null) {
                        AsyncImage(
                            model = Uri.parse(product.imageUri),
                            contentDescription = product.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(90.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    Text(
                        product.name,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text("الباركود: ${product.barcode}")
                    Text("شراء: ${money(product.buyPrice)}")
                    Text("بيع: ${money(product.sellPrice)}")
                    Text("الكمية: ${product.quantity}")
                    Text(
                        "ربح القطعة: ${money(product.sellPrice - product.buyPrice)}"
                    )
                }
            }
        }
    }
}
