package com.market.supermarket.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    var name: String,
    var barcode: String,
    var buyPrice: Double,
    var sellPrice: Double,
    var quantity: Int,
    var minQuantity: Int,
    var imageUri: String? = null
)
