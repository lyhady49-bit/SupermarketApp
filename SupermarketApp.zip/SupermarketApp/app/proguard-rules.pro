# Add project specific ProGuard rules here.
-keep class com.market.supermarket.data.** { *; }
