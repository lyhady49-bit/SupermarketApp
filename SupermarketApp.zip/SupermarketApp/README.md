# تطبيق ماركت (Supermarket Manager)

مشروع Android Studio كامل، محوّل من ملف Compose واحد إلى تطبيق حقيقي متعدد الملفات مع:

- **Room Database**: حفظ دائم للمنتجات، المبيعات، والمصاريف (لم تعد تختفي عند إغلاق التطبيق).
- **ML Kit + CameraX**: مسح باركود حقيقي بالكاميرا (`ui/barcode/BarcodeScannerScreen.kt`).
- **Photo Picker**: إضافة صورة لكل منتج بدون طلب صلاحية تخزين كاملة (`PickVisualMedia`).
- **Navigation Compose**: تنقّل حقيقي بين الشاشات (`navigation/MarketNavHost.kt`) بدل التبديل اليدوي بمتغيّر `screen`.
- **Runtime Permissions**: صلاحية الكاميرا تُطلب فقط عند فتح شاشة المسح، مع شاشة توضيحية إذا رفض المستخدم.

كل الوظائف الأصلية موجودة كما هي: المنتجات، المخزون المنخفض، البيع، التقرير الشهري، حساب الربح.

## كيف تبنيه إلى APK

⚠️ **ملاحظة مهمة وصادقة**: أنا (Claude) أنشأت لك كل ملفات المشروع كاملة، لكن بيئة التنفيذ التي أعمل فيها لا تملك Android SDK ولا اتصال إنترنت، لذلك لم أتمكن من تشغيل Gradle فعلياً لإنتاج ملف `.apk` مُجمَّع. كذلك ملف `gradle-wrapper.jar` (وهو ملف ثنائي) غير موجود في الأرشيف لنفس السبب. البناء الفعلي يحتاج منك خطوة واحدة بسيطة في جهازك:

1. فك ضغط الملف المرفق.
2. افتح Android Studio (Hedgehog أو أحدث) → **Open** → اختر مجلد `SupermarketApp`.
3. سيقوم Android Studio تلقائياً بتوليد `gradle-wrapper.jar` وتنزيل جميع الاعتماديات (Room، ML Kit، CameraX، Navigation...) عبر الإنترنت لديك، ثم يعمل Sync.
4. بعد نجاح الـ Sync: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. ستجد ملف الـ APK في: `app/build/outputs/apk/debug/app-debug.apk` — انسخه لهاتفك وثبّته (فعّل "مصادر غير معروفة" إذا طلب ذلك).

## بنية المشروع

```
app/src/main/java/com/market/supermarket/
├── MainActivity.kt              نقطة الدخول + Compose + Navigation
├── MarketApplication.kt         تهيئة قاعدة البيانات والـ repository
├── data/                        Room: Product, Sale, Expense + DAOs + Database + Repository
├── viewmodel/                   MarketViewModel (يغذي الشاشات من Room عبر Flow)
├── navigation/                  Screen (المسارات) + MarketNavHost (شريط التنقل السفلي)
├── ui/screens/                  Home, Products, Sale, Reports
├── ui/barcode/                  BarcodeScannerScreen (CameraX + ML Kit)
├── ui/components/               InfoCard
└── util/                        دالة تنسيق العملة money()
```

## ملاحظة حول الصلاحيات

الصلاحية الوحيدة المطلوبة هي **الكاميرا**، وتُطلب فقط عند الضغط على "📷 مسح الباركود" (Runtime Permission حقيقية، ليست في وقت التثبيت). صور المنتجات تُختار عبر Photo Picker النظامي في Android، الذي لا يحتاج أي صلاحية تخزين على الإطلاق.
